container = AppLayout(header=header_button,
          left_sidebar=left_button,
          center=fig,
          right_sidebar=None,
          footer=None)
container
