numbers = widgets.Checkbox(description='Include numbers in password',
                           style={'description_width': 'initial'})
numbers
