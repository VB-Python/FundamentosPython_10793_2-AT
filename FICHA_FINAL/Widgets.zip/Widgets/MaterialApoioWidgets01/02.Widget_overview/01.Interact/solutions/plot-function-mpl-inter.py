fig, ax = plt.subplots()
ax.grid()
ctrls = iplt.plot(x, f, k=(.5, 2), p=(0, 2*np.pi))