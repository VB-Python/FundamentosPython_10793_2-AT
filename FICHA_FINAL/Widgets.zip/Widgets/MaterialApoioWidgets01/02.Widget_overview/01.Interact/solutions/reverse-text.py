def reverse(x):
    return x[::-1]

interact(reverse, x='Hello')
