new_side = Sidecar(title="Triple product")

with new_side:
    display(interactive_out_example)
