password_length.observe(calculate_password, names='value')
